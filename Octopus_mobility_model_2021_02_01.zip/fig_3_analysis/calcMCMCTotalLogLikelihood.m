function out = calcMCMCTotalLogLikelihood(x0,childSuscept,genTime,...
    localOnset,genTimeData,...
    totalPopulation,dataOctopus,...
    numIstate,dt,tStart,tEnd,pdfIncubation)


scaleRt = x0(1:4);
seedSize = x0(5);
probReport = x0(6);


totalLogL = totalLogLikelihood(localOnset,genTimeData,...
    scaleRt,childSuscept,genTime,seedSize,probReport,...
    totalPopulation,dataOctopus,...
    numIstate,dt,tStart,tEnd,pdfIncubation);

out = totalLogL;

end

