
clear all;
rng('shuffle');

% 1. Load contact matrix data
% Contact matrix countries
countryText = 'Hong Kong';
% Define age groups
ageGroupDefRange = [-1,12,19,64,101];
totalPop = loadTotalPopulation(countryText);
ageDistributionOneyear =  loadAgeDistrCensus(countryText);
contactMatr = polymodHKcontactMatrix(ageGroupDefRange,ageDistributionOneyear,totalPop);


% 2. Load Octopus data
dateZero = datenum('2019/12/31','yyyy/mm/dd');
% Type of transaction
transType = {'transport_a_','transport_peak_a_','transport_nonpeak_a_','retail_b_'};
cardType = {'adult','child','student','elderly','unknown'};
% Type of transactions
TRANSPORT = 1;
TRANSPORT_PEAK = 2;
TRANSPORT_NONPEAK = 3;
RETAIL = 4;
% Type of Octopus
ADULT = 1;
CHILD = 2;
STUDENT = 3;
ELDERLY = 4;
UNKNOWN = 5;
% Type of subcategory
trans_MTR = 2;
trans_BUS = 3;
trans_MINIBUS = 4;
trans_OTHERTRANS = 5;
trans_TOTAL = 6;
% selected indices in R
selectIdx = [
    TRANSPORT,CHILD,trans_TOTAL;
    TRANSPORT,STUDENT,trans_TOTAL;
    TRANSPORT,ADULT,trans_TOTAL;
    TRANSPORT,ELDERLY,trans_TOTAL;];
dataOctopus = readtable('output/octopus_data_revised_20200531.xlsx');
dataOctopus.date = datenum(dataOctopus.date)-dateZero;

% 3. Load local onset data
localOnset = readtable('case_data/epi_curve_by_onset.csv');
localOnset = localOnset(:,{'date','local'});
dataHK = innerjoin(dataOctopus,localOnset,'LeftKeys','date','RightKeys','date');
genTimeData = readtable('case_data/si_data_20200508.csv');     
genTimeData = genTimeData{:,3:4};
% Model parameters
scaleRt = [0.071, 0.06, 0.0245, 0.02];
childSuscept = 1;
genTime = 5.2;
seedSize = 10;
probReport = 0.3; 

% Fixed parameters
tStart = datenum('2020/01/25','yyyy/mm/dd')-dateZero;
tEndTextArr = {...
    '2020/04/30'};
tEndArr = datenum(tEndTextArr,'yyyy/mm/dd')-dateZero;

for iiTEnd = 1:length(tEndArr)
    tEnd = tEndArr(iiTEnd);
    iiTEndArr = datestr(tEnd+dateZero,'yyyy-mm-dd');
    if exist(strcat('mcmc_result/',iiTEndArr),'dir') == 0
        mkdir(strcat('mcmc_result/',iiTEndArr));
    end
    % incubation period
    meanIncubation = 6.5;
    stdIncubation = 2.6;
    shapeIncu = (stdIncubation*stdIncubation)/meanIncubation;
    scaleIncu = meanIncubation/shapeIncu;
    numDays = tEnd-tStart;
    pdfIncubation = gamcdf(2:(numDays+1),shapeIncu,scaleIncu) - gamcdf(1:numDays,shapeIncu,scaleIncu); 
    pdfIncubation = pdfIncubation(1:20)';
    % Total population for transmission dynamics
    totalPopulation = calcTotalPopulationArrOneYear(loadTotalPopulation('Hong Kong'),loadAgeDistrCensus('Hong Kong'),ageGroupDefRange);
    numIstate = (genTime)^2/((1.72/5.2*genTime)^2);
    numRstate = 4;
    dt = 0.1;

    totalLogL = totalLogLikelihood(localOnset,genTimeData,...
        scaleRt,childSuscept,genTime,seedSize,probReport,...
        totalPopulation,dataOctopus,...
        numIstate,dt,tStart,tEnd,pdfIncubation);
    disp(['Starting log likelihood: ',num2str(totalLogL)]);

     % Test Likelihood function
    x0 = [scaleRt,seedSize,probReport];
    x0LowerBound = [0.001,0.001,0.001,0.001,   1,0];
    x0UpperBound = [ 1.10, 1.10, 1.10, 1.10,1000,1];
    disp(['Starting neg log likelihood: ',num2str(negTotalLogLikelihood(...
        x0,childSuscept,genTime,...
        localOnset,genTimeData,...
        totalPopulation,dataOctopus,...
        numIstate,dt,tStart,tEnd,pdfIncubation))]); 

    % Point estimates from fmincon
    redeffun = @(x)negTotalLogLikelihood(x,childSuscept,genTime,...
        localOnset,genTimeData,...
        totalPopulation,dataOctopus,...
        numIstate,dt,tStart,tEnd,pdfIncubation);
    options = optimoptions(@fmincon,'Display','iter','MaxFunEvals',30000);
    if exist(strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mle.csv'),'file') == 2
        x0 = csvread(strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mle.csv'));
        xfmin = fmincon(redeffun,x0,[],[],[],[],x0LowerBound,x0UpperBound,[],options);
        write_matrix_new(xfmin,strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mle.csv'),'w',',','dec');
    else
        if exist(strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mcmc_res.csv'),'file') == 2
            xfminTemp = csvread(strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mcmc_res.csv'));
            xfminTemp = xfminTemp(xfminTemp(:,1)~=0,:);
            xfmin = xfminTemp(end,:);
            write_matrix_new(xfmin,strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mle.csv'),'w',',','dec');
        else
            xfmin = fmincon(redeffun,x0,[],[],[],[],x0LowerBound,x0UpperBound,[],options);
            write_matrix_new(xfmin,strcat('mcmc_result/',iiTEndArr,'/',countryText,'_mle.csv'),'w',',','dec');
        end
    end

    
    disp(['MLE neg log likelihood: ',num2str(negTotalLogLikelihood(...
        xfmin,childSuscept,genTime,...
        localOnset,genTimeData,...
        totalPopulation,dataOctopus,...
        numIstate,dt,tStart,tEnd,pdfIncubation))]); 

    % MCMC
    mcSteps = 100000;
    if exist(strcat('mcmc_result/',iiTEndArr,'/',countryText,'_parameter_step.csv'),'file') == 2
        stepSize = csvread(strcat('mcmc_result/',iiTEndArr,'/',countryText,'_parameter_step.csv'));
    else
        stepSize = 0.05*(x0UpperBound-x0LowerBound);
    end
    out = mcmcParallel(iiTEndArr,countryText,mcSteps,...
        childSuscept,genTime,...
        localOnset,genTimeData,...
        totalPopulation,dataOctopus,...
        numIstate,dt,tStart,tEnd,pdfIncubation,...
        xfmin,stepSize,x0LowerBound,x0UpperBound);
end