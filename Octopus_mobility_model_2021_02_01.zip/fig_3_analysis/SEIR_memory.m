function out = SEIR_memory(scaleRt,childSuscept,genTime,seedSize,...
    totalPopulation,dataOctopus,...
    numIstate,dt,tStart,tEnd)

maxTime = (tEnd-tStart)+1;
% SEIR model from Wu et al, PLOS Pathogens
numAgeGroup = length(totalPopulation);
% Record variables
incidence = zeros(numAgeGroup,maxTime/dt);
prevalence = zeros(numAgeGroup,maxTime/dt);
% generation time
numStages_I = numIstate;
DI = genTime;
DI_substage = DI/numStages_I;
eps2 = 1e-10;
[aa_Tg, bb_Tg] = gampara(DI, sqrt(numStages_I)*DI_substage);
tmax_Tg = min(ceil(gaminv(1-eps2, aa_Tg, bb_Tg)), 100);
tvec_Tg = 0:dt:tmax_Tg;
generationTimeCDF = gamcdf(tvec_Tg, aa_Tg, bb_Tg);
generationTimePMF = generationTimeCDF(2:end)-generationTimeCDF(1:end-1);
generationTimePMF = generationTimePMF/sum(generationTimePMF);
tii_max_Tg = numel(generationTimePMF);

% Contact matrix
contactMatr = cell(1,maxTime);
iiMobility = zeros(maxTime,numAgeGroup);
ngmBeta = zeros(maxTime,1);

for iiMatr = 1:maxTime
    iiMobility(iiMatr,:) = dataOctopus{tStart+iiMatr-1,3:6};
end
iiMobility = movmean(iiMobility,7);
for iiMatr = 1:maxTime
    contactMatr{iiMatr} = ((scaleRt'*scaleRt).*repmat(iiMobility(iiMatr,:),numAgeGroup,1)).*repmat(iiMobility(iiMatr,:)',1,numAgeGroup,1);
    contactMatr{iiMatr} = contactMatr{iiMatr}.*[...
        childSuscept,childSuscept,1,1;
        childSuscept,childSuscept,1,1;
        childSuscept,childSuscept,1,1;
        childSuscept,childSuscept,1,1];
    [~,ngmDig] = eig(contactMatr{iiMatr}.*repmat(totalPopulation',1,numAgeGroup)*genTime); 
    ngmEig = ngmDig((1:numAgeGroup)+numAgeGroup*(0:(numAgeGroup-1)));
    ngmBeta(iiMatr,1) = max(ngmEig)/10^4;
    contactMatr{iiMatr} = contactMatr{iiMatr}/10^4;
end

% Initial conditions
% 1. State S
% 2. State E
% 3. State I
tii_max = maxTime/dt+1;
stateS = zeros(numAgeGroup, tii_max);
stateR = zeros(numAgeGroup, tii_max);
stateN = zeros(numAgeGroup, tii_max);
stateI = zeros(numAgeGroup, tii_max_Tg, tii_max);

%  Initialize
stateN(:,1) = totalPopulation;
stateI(:,:,1) =  (seedSize*totalPopulation/sum(totalPopulation))'*generationTimePMF;
stateS(:,1) = stateN(:,1) - sum(stateI(:,:,1),2);
startIndex_I = 1;

for tii = 1:(tii_max-1)
    tday = tii*dt;
    contactMatrix = contactMatr{ceil(tday)};
    
    stateI2 = sum(stateI(:,:,tii),2);
    % stateIall = sum(stateI2);
    stateN(:,tii) = stateS(:,tii)+stateI2+stateR(:,tii);
    % stateNall = sum(stateN(:,tii));
    
    incidenceRate = ngmBeta(ceil(tday),1)*(stateS(:,tii).*(contactMatrix*stateI2));
    dSdt = -incidenceRate;
    
    XX = incidenceRate*dt*generationTimePMF;
    if (startIndex_I==1)
        removeIndex = tii_max_Tg;
    else
        removeIndex = startIndex_I-1;
    end
    stateR(:,tii+1) = stateR(:,tii)+stateI(:,removeIndex,tii);
    
    tv = [startIndex_I:tii_max_Tg 1:(startIndex_I-1)];
    stateI(:,tv,tii+1) = stateI(:,tv,tii)+XX;    
    stateI(:,removeIndex,tii+1) = stateI(:,removeIndex,tii+1)-stateI(:,removeIndex,tii);
    
    startIndex_I = startIndex_I+1;
    if (startIndex_I>tii_max_Tg)
        startIndex_I = 1;
    end
    
    stateS(:,tii+1) = stateS(:,tii)+dSdt*dt;
    incidence(:,tii+1) = incidenceRate*dt;
    prevalence(:,tii+1) = stateI2;
end

incidence = incidence';
prevalence = prevalence';
dailyInc = zeros(maxTime,1);
dailyPrev = zeros(maxTime,1);
for tt = 1:maxTime
    dailyInc(tt,:) = sum(sum(incidence((tt-1)/dt+(1:1/dt),:)));
    dailyPrev(tt,:) = sum(sum(prevalence((tt-1)/dt+(1:1/dt),:)*dt));
end

out = [(tStart:tEnd)',dailyInc,dailyPrev];

end

