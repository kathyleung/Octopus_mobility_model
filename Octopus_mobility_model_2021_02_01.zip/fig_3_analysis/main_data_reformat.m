
% 2020-04-16
% Octopus data and incidence correlation

clear all;
dateZero = datenum('2019/12/31','yyyy/mm/dd');

% 2. Read case
dateEnd = datenum('2020/05/15','yyyy/mm/dd')-dateZero;
chpCase = readtable('enhanced_surveillance/hkcase_20200603.csv');
chpCase.onset_date(isnat(chpCase.onset_date)) = datetime(datenum(chpCase.confirm_date(isnat(chpCase.onset_date)))-5, 'ConvertFrom', 'datenum', 'Format', 'dd/mm/yyyy');
chpCase.onset_date_rev = datenum(chpCase.onset_date)-dateZero;
chpCase.confirm_date_rev = datenum(chpCase.confirm_date)-dateZero;
% LKF cluster
lkfCluster = chpCase(strcmp(chpCase.cluster,'Bar & Band'),:);
% tabulate(lkfCluster.onset_date)

% Reclassified lkf type
temp = chpCase.reclassification(ismember(chpCase.case_no,[276,343,362,367,384,386,387,389,432,440]));
temp = repmat({'Epidemiologically linked with imported case'},[length(temp),1]);
chpCase.reclassification(ismember(chpCase.case_no,[276,343,362,367,384,386,387,389,432,440])) = temp;

% typeCase = unique(chpCase.reclassification);
importCase = chpCase(strcmp(chpCase.reclassification,'Imported'),:);
importSecondary = chpCase(strcmp(chpCase.reclassification,'Epidemiologically linked with imported case'),:);
localCase = chpCase(...
    strcmp(chpCase.reclassification,'Local case')|...
    strcmp(chpCase.reclassification,'Possibly local')|...
    strcmp(chpCase.reclassification,'Close contact of local case')|...
    strcmp(chpCase.reclassification,'Close contact of possibly local case')|...
    strcmp(chpCase.reclassification,'Epidemiologically linked with local case'),:);
localCase.onset_date_rev(isnan(localCase.onset_date_rev)) = localCase.confirm_date_rev(isnan(localCase.onset_date_rev))-5;
writetable(localCase,'output/local_case_for_pred.xlsx');

importEpiCurve = histcounts(importCase.onset_date_rev,1:(dateEnd+1));
importSecondaryEpiCurve = histcounts(importSecondary.onset_date_rev,1:(dateEnd+1)); 
localEpiCurve = histcounts(localCase.onset_date_rev,1:(dateEnd+1));
epiData = array2table([(1:dateEnd)',importEpiCurve',importSecondaryEpiCurve',localEpiCurve'],...
    'VariableNames',{'date','import','import_secondary','local'});
writetable(epiData,'case_data/epi_curve_by_onset.csv');

% By date of confirmation
importEpiCurve = histcounts(importCase.confirm_date_rev,1:(dateEnd+1));
importSecondaryEpiCurve = histcounts(importSecondary.confirm_date_rev,1:(dateEnd+1)); 
localEpiCurve = histcounts(localCase.confirm_date_rev,1:(dateEnd+1));
epiData = array2table([(1:dateEnd)',importEpiCurve',importSecondaryEpiCurve',localEpiCurve'],...
    'VariableNames',{'date','import','import_secondary','local'});
writetable(epiData,'case_data/epi_curve_by_confirmation.csv');



