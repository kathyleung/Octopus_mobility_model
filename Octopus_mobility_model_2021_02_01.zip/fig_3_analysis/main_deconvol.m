
clear all

pdfConvolFG  = csvread('case_data/incubation_pdf.csv');
caseReportCount = readtable('case_data/epi_curve_by_onset.csv');

% local
caseReport = caseReportCount.local;
caseReport(caseReport==0) = 1e-9;
deconvolInfection2 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

clf;
figure(2)
plot(caseReport)
hold on
plot(deconvolInfection2(1:(end-3)))

% import
caseReport = caseReportCount.import;
caseReport(caseReport==0) = 1e-9;
deconvolInfection3 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

% import secondary
caseReport = caseReportCount.import_secondary;
caseReport(caseReport==0) = 1e-9;
deconvolInfection4 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

writetable(array2table([...
    deconvolInfection2,...
    deconvolInfection3,...
    deconvolInfection4],...
    'VariableNames',{'local','import','import_secondary'}),'output/deconvolInfection.csv');