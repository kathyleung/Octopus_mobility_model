function totalLogL = totalLogLikelihood(localOnset,genTimeData,...
    scaleRt,childSuscept,genTime,seedSize,probReport,...
    totalPopulation,dataOctopus,...
    numIstate,dt,tStart,tEnd,pdfIncubation)

% 1. Log likelihood of generation time distribution
exactGenTimeLogL = sum(log(gampdf(genTimeData(genTimeData(:,1)==genTimeData(:,2),1),numIstate,genTime/numIstate)));
intervalGenTimeLogL = sum(log(...
    gamcdf(genTimeData(genTimeData(:,1)~=genTimeData(:,2),2),numIstate,genTime/numIstate)-...
    gamcdf(genTimeData(genTimeData(:,1)~=genTimeData(:,2),1),numIstate,genTime/numIstate)));

% 2. Log Likelihood of incidence
dailyInc = SEIR_memory(scaleRt,childSuscept,genTime,seedSize,...
    totalPopulation,dataOctopus,...
    numIstate,dt,tStart,tEnd);
dailyPrevalence = dailyInc(:,3);

if datenum(tEnd)-(datenum('2020/04/15','yyyy/mm/dd')-datenum('2019/12/31','yyyy/mm/dd'))>0
    lessThanOne = (min(dailyPrevalence(...
        dailyInc(:,1)>(datenum('2020/04/15','yyyy/mm/dd')-datenum('2019/12/31','yyyy/mm/dd'))&...
        dailyInc(:,1)<(datenum('2020/04/30','yyyy/mm/dd')-datenum('2019/12/31','yyyy/mm/dd'))...
        ))<1);
else
    lessThanOne = 0;
end

% convolution
dailyOnset = zeros(length(dailyInc)+length(pdfIncubation)-1,1);
for iiDay = 1:length(dailyInc(:,1))
    dailyOnset(iiDay:(iiDay+length(pdfIncubation)-1),1) = dailyOnset(iiDay:(iiDay+length(pdfIncubation)-1),1)+...
        dailyInc(iiDay,2)*pdfIncubation;
end

% Poisson likelihood
obsOnset = dailyOnset*probReport;
obsOnset = [(dailyInc(1)-1+(1:(length(obsOnset))))',obsOnset];

iiOnsetLogL = log(poisspdf(localOnset.local(ismember(localOnset.date,obsOnset(:,1))),...
    obsOnset(ismember(obsOnset(:,1),localOnset.date(ismember(localOnset.date,obsOnset(:,1)))),2)));
onsetLogL = sum(iiOnsetLogL)-(30000*abs(1-min(dailyPrevalence(dailyInc(:,1)>(tEnd-15)))))*lessThanOne;


totalLogL = exactGenTimeLogL+intervalGenTimeLogL+onsetLogL;

end

