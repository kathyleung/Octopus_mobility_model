
# 2020-02-04
# EpiEstim on provincial nCoV epi curves

rm(list = ls());

library(EpiEstim)
library(ggplot2)
library(MASS)
library(xlsx)

dateZero = as.Date('2019-12-31',format = '%Y-%m-%d');

# epi curve
hkEpiCurve = read.csv('output/deconvolInfection.csv',header = TRUE);
hkEpiCurve$date = dateZero+(1:length(hkEpiCurve$local));

# rec
minDate = min(hkEpiCurve$date,na.rm = TRUE);
maxDate = max(hkEpiCurve$date,na.rm = TRUE);

# rec
hkEpiCurve$local[hkEpiCurve$local<0.2] =  0;
hkEpiCurve$local[hkEpiCurve$local>=0.2&hkEpiCurve$local<1] =  1;
rec = data.frame(dates = maxDate+(-(length(hkEpiCurve$date)-1):0),
                 local = round(hkEpiCurve$local),
                 imported = round(hkEpiCurve$import),
                 imported_secondary = round(hkEpiCurve$import_secondary));
minDate = min(rec$dates[rec$local>=1]);
rec = rec[rec$dates>=minDate,];
write.xlsx(rec,'output/hk_est_incidence_by_inf_date.xlsx',sheetName = 'Sheet1',row.names=FALSE);

# 6. Estimate Rt
# si from data
si_data = read.csv('case_data/si_data.csv',header = TRUE,stringsAsFactors = FALSE);
# call function
## fixing the random seeds
MCMC_seed  = 1;
overall_seed  = 2;
mcmc_control = make_mcmc_control(seed = MCMC_seed,burnin = 1000,thin = 10);
# fitting a Gamma dsitribution for the SI
dist = "G";
maxT = length(rec$dates)
t_start = seq(2,(maxT-6));
t_end = t_start+6;
config <- make_config(list(si_parametric_distr = dist,
                           mcmc_control = mcmc_control,
                           seed = overall_seed, 
                           t_start = t_start,
                           t_end=t_end,
                           n1 = 1000, 
                           n2 = 100));

# Overall
inputIncRev = rec;
minDate = rec$dates[1];
res_si_from_data <- estimate_R(inputIncRev,method = "si_from_data",si_data = si_data,config = config);
# record Rt
tempRec = res_si_from_data;
outputRec = tempRec$R;
# add dates
outputRec$t_start = outputRec$t_start+minDate-1;
outputRec$t_end = outputRec$t_end+minDate-1;
write.xlsx(outputRec,paste0('output/hk_weekly_Rt_overall_transmissibility.xlsx'),sheetName = 'Sheet1',row.names = FALSE);

# Excluding imported cases, start estimation
inputIncRev = rec[,c('dates','local')];
colnames(inputIncRev) = c('dates','I');
minDate = rec$dates[1];
res_si_from_data <- estimate_R(inputIncRev,method = "si_from_data",si_data = si_data,config = config);
# record Rt
tempRec = res_si_from_data;
outputRec = tempRec$R;
# add dates
outputRec$t_start = outputRec$t_start+minDate-1;
outputRec$t_end = outputRec$t_end+minDate-1;
write.xlsx(outputRec,paste0('output/hk_weekly_Rt_local_transmissibility.xlsx'),sheetName = 'Sheet1',row.names = FALSE);

# Excluding local cases, start estimation
inputIncRev = rec[,c('dates','imported','imported_secondary')];
colnames(inputIncRev) = c('dates','imported','local');
minDate = rec$dates[1];
res_si_from_data <- estimate_R(inputIncRev,method = "si_from_data",si_data = si_data,config = config);
# record Rt
tempRec = res_si_from_data;
outputRec = tempRec$R;
# add dates
outputRec$t_start = outputRec$t_start+minDate-1;
outputRec$t_end = outputRec$t_end+minDate-1;
write.xlsx(outputRec,paste0('output/hk_weekly_Rt_imported_transmissibility.xlsx'),sheetName = 'Sheet1',row.names = FALSE);

write.xlsx(tempRec$SI.Moments,'output/hk_weekly_Rt_serial_interval.xlsx',sheetName = 'Sheet1',row.names = FALSE);

