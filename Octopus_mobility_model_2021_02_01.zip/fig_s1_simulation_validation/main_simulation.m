
clear all;

% Parameters for simulation
meanInfDur = 6;
totPop = 700*10^4;
iniSIR = [totPop-300-500,300,500];
tmax = 80;
dt = 0.1;
% R0 for simulation
R0Arr(:,1) = 1.2*ones(80,1);
R0Arr(:,2) = smooth([
    2*ones(10,1);
    interp1([10,55],[2,0.4],11:55)';
    0.4*ones(25,1);]);
R0Arr(:,3) = smooth([
    2*ones(10,1);
    interp1([10,45],[2,0.4],11:45)';
    interp1([45,60],[0.4,1.0],46:60)';
    1.0*ones(20,1)]);
    
for iiArr = 1:3
    R0 = R0Arr(:,iiArr);

    [trS,trI,trR,trInc] = determSIR(R0,meanInfDur,totPop,iniSIR,tmax,dt);

    % daily incidence
    for ii = 1:tmax
        dailyInc(ii,1) = sum(trInc((ii-1)*(1/dt)+(1:(1/dt)),1));
    end

    % incubation period distribution
    meanIncubation = 5.2;
    sdIncubation = 2.3;
    incuScale = sdIncubation^2/meanIncubation;
    incuShape = meanIncubation/sdIncubation;
    tmaxIncu = 14;
    pdfIncubation = (gamcdf([1:tmaxIncu,tmax],incuShape,incuScale)-gamcdf(0:tmaxIncu,incuShape,incuScale))';

    dailyOnset = zeros(length(dailyInc)+tmaxIncu,1);
    for ii = 1:tmax
        dailyOnset(ii:(ii+tmaxIncu),1) = dailyInc(ii,1)*pdfIncubation+dailyOnset(ii:(ii+tmaxIncu),1);
    end

    % reporting rate array
    propReport = [0.05,0.1,0.2,0.3];

    % record
    for iiProp  = 1:length(propReport)
        dailyOnsetReport(:,iiProp) = binornd(round(dailyOnset),propReport(iiProp)*ones(size(dailyOnset)));
    end

    dailyOnset = [(1:tmax)',dailyOnsetReport(1:tmax,:),R0(1:tmax)];
    dailyOnset = array2table(dailyOnset,'VariableNames',{'date','no_onsets_1','no_onsets_2','no_onsets_3','no_onsets_4','Rt_infection'});
    writetable(dailyOnset,['data/sim_onset_',num2str(iiArr),'.csv']);
end


