
% 2020-05-07

clear all;
clf;
figure(1)
for iiArr = 1:3
    caseReportCount = readtable(['data/sim_onset_',num2str(iiArr),'.csv']);

    dateZero = datenum('2019/12/31','yyyy/mm/dd');
    simRt = readtable(['data/sim_onset_',num2str(iiArr),'.csv']);
    titleArr = {'p_r_e_p_o_r_t = 0.05','p_r_e_p_o_r_t = 0.1','p_r_e_p_o_r_t = 0.2','p_r_e_p_o_r_t = 0.3'};

    subplot(3,4,(iiArr-1)*4+1)
    hLine = plot(repmat(caseReportCount{:,1},1,3),caseReportCount{:,2:4},'LineWidth',0.75);
    xlim([0,80])
    % ylim([0,120])
    hlegend = legend(hLine,titleArr{1:3});
    if iiArr == 1
        set(hlegend,'box','off','FontSize',9,'Location','Northwest');
    else
        set(hlegend,'box','off','FontSize',9,'Location','Northeast');
    end
    set(gca,'box','off');
    xlabel('Date')
    ylabel('No. of onsets')
    for ii = 1:3
        subplot(3,4,(iiArr-1)*4+1+ii)
        % read data
        estRt = readtable(['output/hk_weekly_Rt_local_transmissibility_',num2str(iiArr),'_',num2str(ii),'.xlsx']);

        estRt.t_start  = datenum(estRt.t_start) - dateZero;
        estRt.t_end  = datenum(estRt.t_end) - dateZero;
        estRt.date = estRt.t_end;

        estRt = join(estRt,simRt);
        estRt.movmeanRt_infection = movmean(estRt.Rt_infection,7);

        comp = estRt(:,[3,17,18]);
        estRt = estRt(2:(end-3),:);

        hPatch = patch('XData',[(estRt.date)',fliplr((estRt.date)')],...
            'YData',[(estRt{:,5})',fliplr((estRt{:,11})')],...
            'FaceColor','red',...
            'EdgeColor','none',...
            'FaceAlpha',0.1);
        hLine2 = line(estRt.date,estRt{:,3},'Color',[0.8500, 0.3250, 0.0980],'LineWidth',0.75);
        hold on
        hLine1 = line(estRt.date,estRt{:,17},'Color',[0, 0.4470, 0.7410],'LineWidth',0.75);

    %     % legend
    %     if ii ==1
    %         hlegend = legend([hLine1,hLine2],...
    %             {'R_t used in simulation','R_t estimated from the deconvoluted epi-curve'});
    %         set(hlegend,'box','off','FontSize',8);
    %     end
        xlim([0,80])
        ylim([0,3])
        text(0.65,0.85,titleArr{ii},'FontSize',9,'Units','Normalized')
        xlabel('Date')
        ylabel('R_t')
        hold on
    end
    hold on
end