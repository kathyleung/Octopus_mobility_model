
clear all

pdfConvolFG  = csvread('data/incubation_pdf.csv');

for iiArr = 1:3
    
    caseReportCount = readtable(['data/sim_onset_',num2str(iiArr),'.csv']);

    % local
    tBegin = 0;

    caseReport = [zeros(tBegin,1);caseReportCount.no_onsets_1];
    caseReport(caseReport==0) = 1e-7;
    deconvolInfection1 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

    caseReport = [zeros(tBegin,1);caseReportCount.no_onsets_2];
    caseReport(caseReport==0) = 1e-7;
    deconvolInfection2 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

    caseReport = [zeros(tBegin,1);caseReportCount.no_onsets_3];
    caseReport(caseReport==0) = 1e-7;
    deconvolInfection3 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

    caseReport = [zeros(tBegin,1);caseReportCount.no_onsets_4];
    caseReport(caseReport==0) = 1e-7;
    deconvolInfection4 = DeconvolutionIncidence1(caseReport,pdfConvolFG);

    writetable(array2table([...
        deconvolInfection1((tBegin+1):end,1),...
        deconvolInfection2((tBegin+1):end,1),...
        deconvolInfection3((tBegin+1):end,1),...
        deconvolInfection4((tBegin+1):end,1)],...
        'VariableNames',{'local_1','local_2','local_3','local_4'}),...
        ['output/deconvolInfection_',num2str(iiArr),'.csv']);
end