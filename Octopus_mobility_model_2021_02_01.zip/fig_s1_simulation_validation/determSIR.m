function [trS,trI,trR,trInc,R0Rec] = determSIR(R0,meanInfDur,totPop,iniSIR,tmax,dt)

numTStep = tmax/dt;
trS = zeros(numTStep,1);
trI = zeros(numTStep,1);
trR = zeros(numTStep,1);
trInc = zeros(numTStep,1);
trS(1) = iniSIR(1);
trI(1) = iniSIR(2);
trR(1) = iniSIR(3);
trInc(1) = 0;

% Simple deterministic SIR
for ii = 1:(numTStep-1)
    beta = R0(ceil(dt*ii))/meanInfDur/totPop;
    numInfection = beta*trI(ii)*trS(ii)*dt;
    numRecovery = 1/meanInfDur*trI(ii)*dt;
    trS(ii+1) = trS(ii)-numInfection;
    trI(ii+1) = trI(ii)+numInfection-numRecovery;
    trR(ii+1) = trR(ii)+numRecovery;
    trInc(ii) = numInfection;
    R0Rec(ii) = R0(ceil(dt*ii));
end

end

