
# 2020-02-04
# EpiEstim on provincial nCoV epi curves

rm(list = ls());

library(EpiEstim)
library(ggplot2)
library(MASS)
library(xlsx)

dateZero = as.Date('2019-12-31',format = '%Y-%m-%d');

# epi curve
for(iiArr in 1:3){
  
  hkEpiCurve = read.csv(paste0('output/deconvolInfection_',as.character(iiArr),'.csv'),header = TRUE);
  hkEpiCurve$date = dateZero+(1:length(hkEpiCurve$local_1));
  
  # rec
  minDate = min(hkEpiCurve$date,na.rm = TRUE);
  maxDate = max(hkEpiCurve$date,na.rm = TRUE);
  
  for(ii in 1:(length(hkEpiCurve[1,])-1)){
    # rec
    rec = data.frame(dates = maxDate+(-(length(hkEpiCurve$date)-1):0),
                     local = round(hkEpiCurve[,ii]),
                     imported = 0,
                     imported_secondary = 0);
    minDate = min(rec$dates[rec$local>=1]);
    rec = rec[rec$dates>=minDate,];
    write.xlsx(rec,paste0('output/hk_est_incidence_by_inf_date_',as.character(iiArr),'_',as.character(ii),'.xlsx'),sheetName = 'Sheet1',row.names=FALSE);
    
    # 6. Estimate Rt
    # call function
    ## fixing the random seeds
    MCMC_seed  = 1;
    overall_seed  = 2;
    mcmc_control = make_mcmc_control(seed = MCMC_seed,burnin = 1000,thin = 10);
    # fitting a Gamma dsitribution for the SI
    dist = "G";
    maxT = length(rec$dates)
    t_start = seq(2,(maxT-6));
    t_end = t_start+6;
    config <- make_config(list(mean_si = 6,
                               std_si = 6,
                               mcmc_control = mcmc_control,
                               seed = overall_seed, 
                               t_start = t_start,
                               t_end=t_end,
                               n1 = 1000, 
                               n2 = 100));
    
    # Excluding imported cases, start estimation
    inputIncRev = rec[,c('dates','local')];
    colnames(inputIncRev) = c('dates','I');
    minDate = rec$dates[1];
    res_si_from_data <- estimate_R(inputIncRev,method = "parametric_si",config = config);
    # record Rt
    tempRec = res_si_from_data;
    outputRec = tempRec$R;
    # add dates
    outputRec$t_start = outputRec$t_start+minDate-1;
    outputRec$t_end = outputRec$t_end+minDate-1;
    write.xlsx(outputRec,paste0('output/hk_weekly_Rt_local_transmissibility_',as.character(iiArr),'_',as.character(ii),'.xlsx'),sheetName = 'Sheet1',row.names = FALSE);
  }
}
